from setuptools import setup

setup(
    name='pythonFlask',
    version='1.0.0',
    packages=['flaskr'],
    url='https://tk-tatsuro-app.com',
    license='Free',
    author='tk-tatsuro',
    author_email='',
    description='SNS sample package'
)
